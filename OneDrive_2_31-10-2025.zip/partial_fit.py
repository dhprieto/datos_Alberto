import pandas as pd
import numpy as np
import os
import pickle
from bayesian_hyper import export_errors_indices

new_data = pd.read_excel(r"C:\Users\dres2\OneDrive - Universidad Politécnica de Cartagena\Documentos\repositories\datos_Alberto\new_data\Experimento_modificaciones_16ºC.xlsx")
path_data = r"C:\Users\dres2\OneDrive - Universidad Politécnica de Cartagena\Documentos\repositories\datos_Alberto\new_data"

df_list = {}

# reading new data

for dataset_ in os.listdir(path_data):
    
    if dataset_ != "Experimento_modificaciones_16ºC.xlsx":
        # Temperatura	pH	Aw	p	Crec
        path = os.path.join(path_data, dataset_)
        dataset = pd.read_csv(path, sep= "\t")
    
    else:
        dataset = pd.read_excel(r"C:\Users\dres2\OneDrive - Universidad Politécnica de Cartagena\Documentos\repositories\datos_Alberto\new_data\Experimento_modificaciones_16ºC.xlsx")
        dataset.rename(columns={"Temp" : "Temperatura"}, inplace=True)

    dataset.loc[: , "Bw"] = np.sqrt(1 - dataset.loc[: , "Aw"])
    dataset.loc[: , "Aw2"] = dataset.loc[: , "Aw"] ** 2
    dataset.loc[: , "T2"] = dataset.loc[: , "Temperatura"]**2
    dataset.loc[: , "pH2"] = dataset.loc[: , "pH"] ** 2
    dataset.loc[: , "Bw2"] = dataset.loc[: , "Bw"] ** 2
    dataset.loc[: , "TxpH"] = dataset.loc[: , "Temperatura"] * dataset.loc[: , "pH"]
    dataset.loc[: , "TxAw"] = dataset.loc[: , "Temperatura"] * dataset.loc[: , "Aw"]
    dataset.loc[: , "TxBw"] = dataset.loc[: , "Temperatura"] * dataset.loc[: , "Bw"]
    dataset.loc[: , "pHxAw"] = dataset.loc[: , "pH"] * dataset.loc[: , "Aw"]
    dataset.loc[: , "pHxBw"] = dataset.loc[: , "pH"] * dataset.loc[: , "Bw"]


    df_list[dataset_] = dataset


path_models = r"C:\Users\dres2\OneDrive - Universidad Politécnica de Cartagena\Documentos\repositories\models_datos_Alberto\models\Second execution"
models_ = ["SGD_second.p", "perceptron_second.p", "PassAg_second.p"] # os.listdir(path_models)

list_models = {}

# loading models to be incremented

for model in models_:
    path = os.path.join(path_models, model)
    
    with open(path, "rb") as f:
        model_loaded = pickle.load(f) 
    list_models[model] = model_loaded

df_train = df_list["Experimento_modificaciones_16ºC.xlsx"]

Y = df_train["Crec"].values
X = df_train.drop(["Crec", "Muestra"], axis = 1)

# array(['Temperatura', 'pH', 'Aw', 'Bw', 'T2', 'pH2', 'Aw2', 'Bw2', 'TxpH', 'TxAw', 'pHxAw', 'TxBw', 'pHxBw'], dtype=object)
# X_1 = X.iloc[:,[0,1,2]]

new = list_models["SGD_second.p"].named_steps["SGD"].partial_fit(X, 1-Y)
print(new)

new = list_models["perceptron_second.p"].named_steps["PR"].partial_fit(X, 1-Y)
print(new)

new = list_models["PassAg_second.p"].named_steps["toxic"].partial_fit(X, 1-Y)
print(new)
